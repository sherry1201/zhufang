package com.fhyTest.VueAndSpringboot.controller;


import com.fhyTest.VueAndSpringboot.service.userService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;


import javax.servlet.http.HttpSession;
import java.util.Collection;

import java.util.List;
import java.util.Map;
@RestController
public class userController extends BaseController{
    @Autowired
    private userService service;

    @Autowired
    private JavaMailSender javaMailSender;

    @GetMapping("queryUser")
    public Map<String,Object> queryUser(@RequestParam Map<String,Object> map){
        if(map.size()!=0){
            int totalCount = service.queryUserCount(map);//拿到数据的总条数
            map.put("totalCount",totalCount);
        }


        Map<String,Object> map1 = selectLimt(map);
        map1.put("list",service.queryPageUserList(map));
        return map1;
    }
    //删除用户信息  单个删除
    @GetMapping("deleteUser")
    public List<Map<String,Object>> deleteRoom(@RequestParam int userId){
        int count = service.deleteUser(userId);
        return service.selectUser();
    }
    // 多选删除
    @GetMapping("mulDeleteUser")
    public List<Map<String,Object>> mulDeleteUser(@RequestParam Map<String,Object> map){
        Collection<Object> list =map.values();
        for (Object ID :list){
            int count = service.deleteUser(Integer.parseInt(ID.toString()));
        }
        return service.selectUser();
    }

    @GetMapping("updateUser")
    public void updateUser(@RequestParam Map<String,Object> map){
        // System.out.println(map);
        int count = service.updateUser(map);
    }

    @GetMapping("insertUser")
    public void insertUser(@RequestParam Map<String,Object> map){
        int count=service.insertUser(map);
    }

}




