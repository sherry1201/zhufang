package com.fhyTest.VueAndSpringboot.controller;

import com.fhyTest.VueAndSpringboot.service.houseService;
import com.fhyTest.VueAndSpringboot.service.roomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@RestController
public class huoseController extends BaseController {

    @Autowired
    private houseService service;


    @GetMapping("queryHouse")
    public Map<String,Object> queryHouse(@RequestParam Map<String,Object> map){

        if(map.size()!=0){
            int totalCount = service.queryHouseCount(map);//拿到数据的总条数
            map.put("totalCount",totalCount);
        }
        Map<String,Object> map1 = selectLimt(map);
        map1.put("list",service.queryPageHouseList(map));
        return map1;
    }
    //删除房屋信息  单个删除
    @GetMapping("deleteHouse")
    public List<Map<String,Object>> deleteCommunity(@RequestParam int houseId){
        int count = service.deleteHouse(houseId);
        return service.selectHouse();
    }
    // 多选删除
    @GetMapping("mulDeleteHouse")
    public List<Map<String,Object>> mulDeleteHouse(@RequestParam Map<String,Object> map){
        Collection<Object> list =map.values();
        for (Object ID :list){
            int count = service.deleteHouse(Integer.parseInt(ID.toString()));
        }
        return service.selectHouse();
    }

    @GetMapping("updateHouse")
    public void updateRoom(@RequestParam Map<String,Object> map){
        int count = service.updateHouse(map);
    }

    @GetMapping("insertHouse")
    public void insertHouse(@RequestParam Map<String,Object> map){
        int count=service.insertHouse(map);
    }

    @GetMapping("queryHouseNameAndId")
    public List<Map<String,Object>> queryHouseNameAndId(int communityId){
        return service.queryHouseNameAndId(communityId);
    }


}
