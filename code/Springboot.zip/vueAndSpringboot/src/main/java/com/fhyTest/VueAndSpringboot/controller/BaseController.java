package com.fhyTest.VueAndSpringboot.controller;
import com.fhyTest.VueAndSpringboot.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.util.*;

public class BaseController {
    @Autowired
    private userService uService;

    @Autowired
    private questionService qService;

    @Autowired
    private roomService rService;

    @Autowired
    private houseService hService;

    @Autowired
    private communityService cService;

    @Autowired
    private HttpSession session;

    @Autowired
    private collectService coService;


    //    分页
    public Map<String,Object> selectLimt(@RequestParam Map<String,Object> map){
        if (map.get("pageIndex") != null && map.get("pageSize") != null) {
            //这里有执行分页的相关代码
            int pageIndex = Integer.parseInt(map.get("pageIndex").toString());//拿到当前页
            int pageSize = Integer.parseInt(map.get("pageSize").toString());//拿到每页的最大条数
            int totalCount =Integer.parseInt(map.get("totalCount").toString());//拿到数据的总条数

            int totalPage = totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1;//总的页数
            int start = (pageIndex - 1) * pageSize;
            map.put("totalCount", totalCount);
            map.put("totalPage", totalPage);
            map.put("start", start);
            map.put("pageSize", pageSize);
//                list=service.queryPageUserList(map);//limit start,pageSize
//                map.put("list",list);
        } else {
//                list=service.queryPageUserList(map);
//                map.put("list",list);
        }

        return map;
    }

    //上传
    public String uploadFile(@RequestParam("file") MultipartFile file){
        String fileName=file.getOriginalFilename();//是文件的全名
        String filePath="D:\\lessonproject\\lessonproject\\src\\assets\\";//路径
//        String filePath="D:/upload";
        File d=new File(filePath+fileName);
        try{
            file.transferTo(d);
        }catch (Exception e){
        }
        return fileName;
    }

    public String uploadFile1(@RequestParam("file") MultipartFile file){
        String fileName=file.getOriginalFilename();//是文件的全名
        String newFileName= UUID.randomUUID().toString()+fileName.substring(fileName.lastIndexOf("."));

        String filePath="D:\\lessonproject\\lessonproject\\src\\assets\\";//路径
        File d=new File(filePath+newFileName);
        try{
            file.transferTo(d);
        }catch (Exception e){
        }
        return newFileName;
    }

    public Map<String,Object> roomAllData(Map<String,Object> map){


        Map<String,Object> mapRoom ;

        List<Map<String,Object>> list=rService.queryPageRoomList(map);
        mapRoom = list.get(0);

        String str1 [] = list.get(0).get("houseUserlist").toString().split(",");

        List<Map<String,Object>> listUser = new ArrayList<Map<String,Object>>();
        Map<String,Object> mapUserId = new HashMap<String,Object>();
        if (str1.length>0){
            for(int i=0;i<str1.length;i++){

                mapUserId.put("userId",str1[i]);
                list = uService.queryPageUserList(mapUserId);
                list.get(0).put("userUrl",img(list.get(0).get("userUrl").toString()));

                listUser.add(i,list.get(0));
                mapUserId.remove("userId");
            }
            mapRoom.put("list",listUser);
        }


        List<Map<String,Object>> listCo = coService.queryPageCollectList(map);
        if(listCo.size()!=0){
            mapRoom.put("collect",1);
        }else{
            mapRoom.put("collect",0);
        }
        mapRoom.put("userId",map.get("userId").toString());
        return mapRoom;
    }

    public Map<String,Object> myAllCollect(Map<String,Object> map){
        Map<String,Object> mapDate = new HashMap<String,Object>();
        List<Map<String,Object>> listCo = coService.queryPageCollectList(map);
        List<Map<String,Object>> listRoom = new ArrayList<Map<String,Object>>();
        if(listCo.size()!=0){


            for(int i=0;i<listCo.size();i++){
                map.put("roomId", listCo.get(i).get("roomId").toString());
                Map<String,Object> map1= rService.queryPageRoomList(map).get(0);
                map1.put("roomUrl",img(map1.get("roomUrl").toString()));

                listRoom.add(i,map1);
                listRoom.get(i).put("collectId",listCo.get(i).get("collectId").toString());
            }
        }
        mapDate.put("list",listRoom);


        mapDate.put("userId",map.get("userId"));
        return mapDate;
    }

    public String img (String url){
        String str[] = url.split("\\\\");
        url = str[str.length-1];
        return "img/"+url;
    }

}
