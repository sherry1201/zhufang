package com.fhyTest.VueAndSpringboot.controller;

import com.fhyTest.VueAndSpringboot.service.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@RestController
public class DataController extends BaseController{
    @Autowired
    private userService service;

    @Autowired
    private JavaMailSender javaMailSender;


    @PostMapping("userLogon")
    public String userLogin(@RequestParam Map<String,Object> map, HttpSession session){

        if(!(map.get("userAccount").toString().trim().equals("")) && !(map.get("userPassword").toString().trim().equals("")) ){
            List<Map<String,Object>> list = service.queryPageUserList(map);


            if(list.size()!=0){
                list.get(0).put("userUrl",img( list.get(0).get("userUrl").toString()));
                session.setAttribute("map", list.get(0));

                return "1";
            }else {

                return "0";
            }
        }else {

            return "0";
        }


    }

    @PostMapping("forgetPassword")
    public String forgetPassword(@RequestParam Map<String,Object> map) {
        List<Map<String,Object>> list = service.queryPageUserList(map);
        if(list.size()!=0){
            String mail = list.get(0).get("userMail").toString();

            SimpleMailMessage message = new SimpleMailMessage();
            message.setSubject("密码找回");
            message.setFrom("1509248355@qq.com");
            message.setTo(mail);
            message.setText("亲爱的"+list.get(0).get("userName").toString()+"你的密码是"+list.get(0).get("userPassword").toString());
            javaMailSender.send(message);
            return "1";
        }else {
            return "0";
        }
    }


    @PostMapping("updateUserPassword")
    public String updateUserPassword(@RequestParam Map<String,Object> map,HttpSession session, SessionStatus sessionStatus) {
        List<Map<String,Object>> list = service.queryPageUserList(map);
        if(list.size()!=0){
            map.put("userId",list.get(0).get("userId").toString());
            service.updateUser(map);
            //清除session
            session.invalidate();
            sessionStatus.setComplete();
            return "1";
        }else {

            return "0";
        }
    }




    @GetMapping("firstImg")
    public String firstImg(){
        return "first.png";
    }

    @PostMapping("testAccount")
    public String testAccount(@RequestParam Map<String,Object> map, HttpSession session){

        List<Map<String,Object>> list = service.queryPageUserList(map);
        if(list.size()!=0){
            return "1";
        }else {
            return "0";
        }
    }

    @PostMapping("testPhone")
    public String testPhone(@RequestParam Map<String,Object> map, HttpSession session){

        List<Map<String,Object>> list = service.queryPageUserList(map);
        if(list.size()!=0){
            return "1";
        }else {
            return "0";
        }
    }

    @PostMapping("testMail")
    public String testMail(@RequestParam Map<String,Object> map, HttpSession session){

        List<Map<String,Object>> list = service.queryPageUserList(map);
        if(list.size()!=0){
            return "1";
        }else {
            return "0";
        }
    }


}
