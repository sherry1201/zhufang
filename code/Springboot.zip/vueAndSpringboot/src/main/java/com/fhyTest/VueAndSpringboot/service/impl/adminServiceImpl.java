package com.fhyTest.VueAndSpringboot.service.impl;

import com.fhyTest.VueAndSpringboot.mapper.adminMapper;
import com.fhyTest.VueAndSpringboot.service.adminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
@Service
public class adminServiceImpl implements adminService {
  @Autowired
  private adminMapper mapper;
  @Override
  public List<Map<String, Object>> queryAdmin() {
    return mapper.queryAdmin();
  }

  @Override
  public int deleteAdmin(int adminId) {
    return mapper.deleteAdmin(adminId);
  }

  @Override
  public int insertAdmin(Map<String, Object> map) {
    return mapper.insertAdmin(map);
  }

  @Override
  public int updateAdmin(Map<String, Object> map) {
    return mapper.updateAdmin(map);
  }

  @Override
  public int queryAdminCount(Map<String, Object> map) {
    return mapper.queryAdminCount(map);
  }

  @Override
  public Map<String, Object> queryPageAdminList(Map<String, Object> map) {
    return mapper.queryPageAdminList(map);
  }
}
