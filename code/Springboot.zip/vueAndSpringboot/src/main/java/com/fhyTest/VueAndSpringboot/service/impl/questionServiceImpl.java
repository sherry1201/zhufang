package com.fhyTest.VueAndSpringboot.service.impl;

import com.fhyTest.VueAndSpringboot.mapper.questionMapper;
import com.fhyTest.VueAndSpringboot.service.questionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class questionServiceImpl implements questionService{
    @Autowired
    questionMapper mapper;

    @Override
    public List<Map<String, Object>> selectQuestion() {
        return mapper.selectQuestion();
    }
}
