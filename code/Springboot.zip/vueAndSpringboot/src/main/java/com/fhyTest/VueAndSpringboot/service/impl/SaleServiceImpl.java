package com.fhyTest.VueAndSpringboot.service.impl;

import com.fhyTest.VueAndSpringboot.mapper.roomMapper;
import com.fhyTest.VueAndSpringboot.mapper.saleMapper;
import com.fhyTest.VueAndSpringboot.service.saleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SaleServiceImpl implements saleService {

    @Autowired
    saleMapper mapper;

    @Override
    public List<Map<String, Object>> selectSale() {
        return mapper.selectSale();
    }

    @Override
    public int  insertSale(Map<String, Object> map) {
        return mapper.insertSale(map);
    }

    @Override
    public int updateSale(Map<String, Object> map) {
        return mapper.updateSale(map);
    }

    @Override
    public int querySaleCount(Map<String, Object> map) {
        return mapper.querySaleCount(map);
    }

    @Override
    public List<Map<String, Object>> queryPageSaleList(Map<String, Object> map) {
        return mapper.queryPageSaleList(map);
    }

    @Override
    public int deleteSale(int saleId) {
        return mapper.deleteSale(saleId);
    }

    @Override
    public int querySaleId(String saleroomid) {
        return mapper.querySaleId(saleroomid);
    }

    @Override
    public List<Map<String, Object>> querySaleNameAndId() {
        return mapper.querySaleNameAndId();
    }
}
