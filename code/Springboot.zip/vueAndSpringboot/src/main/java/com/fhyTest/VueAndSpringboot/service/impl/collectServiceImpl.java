package com.fhyTest.VueAndSpringboot.service.impl;

import com.fhyTest.VueAndSpringboot.mapper.adminMapper;
import com.fhyTest.VueAndSpringboot.mapper.collectMapper;
import com.fhyTest.VueAndSpringboot.service.collectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class collectServiceImpl implements collectService {
    @Autowired
    private collectMapper mapper;

    @Override
    public List<Map<String, Object>> queryCollect() {
        return mapper.queryCollect();
    }

    @Override
    public int deleteCollect(int collectId) {
        return mapper.deleteCollect(collectId);
    }

    @Override
    public int insertCollect(Map<String, Object> map) {
        return mapper.insertCollect(map);
    }

    @Override
    public int updateCollect(Map<String, Object> map) {
        return mapper.updateCollect(map);
    }

    @Override
    public int queryCollectCount(Map<String, Object> map) {
        return mapper.queryCollectCount(map);
    }

    @Override
    public List<Map<String,Object>> queryPageCollectList(Map<String, Object> map) {
        return mapper.queryPageCollectList(map);
    }

    @Override
    public void collectDelete(Map<String,Object> map) {
        mapper.collectDelete(map);
    }
}
