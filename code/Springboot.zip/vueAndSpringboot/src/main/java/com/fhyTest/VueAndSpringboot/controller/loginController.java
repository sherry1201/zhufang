package com.fhyTest.VueAndSpringboot.controller;

import com.fhyTest.VueAndSpringboot.service.adminService;
import com.fhyTest.VueAndSpringboot.service.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class loginController {
  @Autowired
//  private userService service;
  private adminService service;

  //登录验证
//  @GetMapping("/loginCheck")
//  public String loginCheck(@RequestParam String userAccount,@RequestParam String userPassword){
//    if (userAccount == "" || userAccount == null){
//      return "请输入账号";
//    }else {
//      if (userPassword == "" || userPassword == null){
//        return "请输入密码";
//      }
//    }
//    List<Map<String,Object>> list = service.queryUserList();
//    for (int i=0; i<list.size(); i++){
//      if (list.get(i).get("userAccount").equals(userAccount)){
//        if (list.get(i).get("userPassword").equals(userPassword)){
//          return "1";
//        }
//      }
//    }
//    return "密码错误！";
//  }
//
//  @GetMapping("/insertAdmin")
//  public int insertAdmin(@RequestParam Map<String,Object> map){
//    service.insertAdmin(map);
//    return 1;
//  }

  //登录验证
  @GetMapping("/loginCheck")
  public Map<String,Object> loginCheck(@RequestParam Map<String,Object> map){

    Map<String,Object> m= new HashMap<String,Object>();
    List<Map<String,Object>> list = service.queryAdmin();
    for (int i = 0 ; i< list.size() ;i++){
      if (list.get(i).get("adminAccount").toString().equals(map.get("adminAccount"))){
        if (list.get(i).get("adminPassword").toString().equals(map.get("adminPassword"))){
          m.put("res","1");
          m.put("list",list.get(i));
          return m;
        }else {
          m.put("res","密码错误");
          return m;
        }
      }else {
        m.put("res","账号未注册!");
        return m;
      }
    }
    return m;
  }

  //删除用户信息  单个删除
  @GetMapping("deleteAdmin")
  public List<Map<String,Object>> deleteAdmin(@RequestParam int adminId){
    int count = service.deleteAdmin(adminId);
    return service.queryAdmin();
  }


  @GetMapping("queryAdmin")
  public String queryAdmin(@RequestParam Map<String,Object> map){
    Map<String,Object> map1 =service.queryPageAdminList(map);
    System.out.println(map1);
    if(map1!=null){
      return "有数据！";
    }else{
      return "无数据！";
    }
  }

  @GetMapping("updateAdmin")
  public String updateAdmin(@RequestParam Map<String,Object> map){
    // System.out.println(map);
    int count = service.updateAdmin(map);
    System.out.println(count);
    return "index";
  }

  @GetMapping("insertAdmin")
  public String insertAdmin(@RequestParam Map<String,Object> map){
    int count=service.insertAdmin(map);
    System.out.println(count);
    return "sds";
  }




}
