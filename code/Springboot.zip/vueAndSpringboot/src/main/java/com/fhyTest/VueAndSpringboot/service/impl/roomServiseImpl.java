package com.fhyTest.VueAndSpringboot.service.impl;
import com.fhyTest.VueAndSpringboot.mapper.communityMapper;
import com.fhyTest.VueAndSpringboot.mapper.roomMapper;
import com.fhyTest.VueAndSpringboot.service.roomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class roomServiseImpl implements roomService {

    @Autowired
    roomMapper mapper;


    @Override
    public List<Map<String, Object>> selectRoom() {
        return mapper.selectRoom();
    }
    @Override
    public int insertRoom(Map<String, Object> map) {
        return mapper.insertRoom(map);
    }

    @Override
    public int updateRoom(Map<String, Object> map) {
        return mapper.updateRoom(map);
    }

    @Override
    public int queryRoomCount(Map<String, Object> map) {
        return mapper.queryRoomCount(map);
    }

    @Override
    public List<Map<String, Object>> queryPageRoomList(Map<String, Object> map) {
        return mapper.queryPageRoomList(map);
    }
    //删除
    @Override
    public int deleteRoom(int roomId) {
        return mapper.deleteRoom(roomId);
    }

    @Override
    public int updateSaleId(Map<String, Object> map) {
        return mapper.updateSaleId(map);
    }

    @Override
    public int queryRoomInnerJoinHouseCount(Map<String, Object> map) {
        return mapper.queryRoomInnerJoinHouseCount(map);
    }
}
