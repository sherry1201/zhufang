package com.fhyTest.VueAndSpringboot.service;

import java.util.List;
import java.util.Map;

public interface saleService {
    public List<Map<String,Object>> selectSale();

    public int insertSale(Map<String,Object> map);
//
    public int updateSale(Map<String,Object> map);
//
    public int querySaleCount(Map<String,Object> map);

    public List<Map<String,Object>> queryPageSaleList(Map<String,Object> map);
//
    public int deleteSale(int saleId);
    //添加销售员时 返回销售员的Id
    public int  querySaleId(String saleroomid);
    //添加房屋是 选择需要管理员的Id和姓名
    public List<Map<String,Object>> querySaleNameAndId();
}
