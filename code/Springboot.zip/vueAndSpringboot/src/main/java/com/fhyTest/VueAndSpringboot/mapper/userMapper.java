package com.fhyTest.VueAndSpringboot.mapper;
import org.springframework.stereotype.Repository;

        import java.util.List;
        import java.util.Map;
@Repository
public interface userMapper {
//  //  查询用户数据
//  public List<Map<String,Object>> queryUserList();
//  //注册用户
//  public int insertUser(Map<String,Object> map);
    public List<Map<String,Object>> selectUser();

    public int insertUser(Map<String,Object> map);
//
    public int updateUser(Map<String,Object> map);
//
    public int queryUserCount(Map<String,Object> map);

    public List<Map<String,Object>> queryPageUserList(Map<String,Object> map);
//
    public int deleteUser(int userId);

    public List<Map<String,Object>> queryUserAndQuestion(Map<String,Object> map);

    public List<Map<String,Object>> queryUserAndRoom(Map<String,Object> map);

}
