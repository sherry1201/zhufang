package com.fhyTest.VueAndSpringboot.mapper;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface houseMapper {
    public List<Map<String,Object>> selectHouse();

    public int insertHouse(Map<String,Object> map);
//
    public int updateHouse(Map<String,Object> map);
//
    public int queryHouseCount(Map<String,Object> map);

    public List<Map<String,Object>> queryPageHouseList(Map<String,Object> map);
//
    public int deleteHouse(int houseId);
    //获取house、的名字 和 Id
    public List<Map<String,Object>>  queryHouseNameAndId(int communityId);

}
