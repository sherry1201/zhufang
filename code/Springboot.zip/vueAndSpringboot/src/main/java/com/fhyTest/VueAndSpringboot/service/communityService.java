package com.fhyTest.VueAndSpringboot.service;

import java.util.List;
import java.util.Map;

public interface communityService {

    public List<Map<String,Object>> selectCommunity();
    public int insertCommunity(Map<String,Object> map);
//
    public int updateCommunity(Map<String,Object> map);
//
    public int queryCommunityCount(Map<String,Object> map);
//
    public List<Map<String,Object>> queryPageCommunityList(Map<String,Object> map);
//
    public int deleteCommunity(int communityId);

    //查询没有管理员管理room 所在小区的名字
    public List<Map<String,Object>> queryNullSaleid();
    //查询小区的名字和id
    public List<Map<String,Object>> queryCommunityIdAndName();
}
