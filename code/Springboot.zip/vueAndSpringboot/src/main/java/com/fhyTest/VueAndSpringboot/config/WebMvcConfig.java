package com.fhyTest.VueAndSpringboot.config;

import com.fhyTest.VueAndSpringboot.intercepors.LoginInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;


@Configuration
public class WebMvcConfig extends WebMvcConfigurationSupport {
    @Autowired
    private LoginInterceptor loginInterceptor;
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
//        registry.addResourceHandler("/img/**").addResourceLocations("file:/d:/upload/");
        registry.addResourceHandler("/img/**").addResourceLocations("file:/D:\\lessonproject\\lessonproject\\src\\assets\\");

        registry.addResourceHandler("/js/**").addResourceLocations("file:/d:/js/");
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        // addPathPatterns("/**") 表示拦截所有的请求，
//             excludePathPatterns("/login", "/register"); //表示除了登陆与注册之外，因为登陆注册不需要登陆也可以访问
        registry.addInterceptor(loginInterceptor).addPathPatterns("/**").excludePathPatterns("/first", "/userLogin","/userLogon", "/roomList","","/img/**","/js/**","/firstImg","/testAccount","testPhone","testMail");
    }


}
