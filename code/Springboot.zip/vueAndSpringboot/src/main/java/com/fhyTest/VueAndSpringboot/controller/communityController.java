package com.fhyTest.VueAndSpringboot.controller;

import com.fhyTest.VueAndSpringboot.service.communityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;

@RestController
public class communityController extends BaseController {
    @Autowired
    private communityService service;

    @GetMapping("queryCommunity")
    public Map<String,Object> queryCommunity(@RequestParam Map<String,Object> map){

        if(map.size()!=0){
            int totalCount = service.queryCommunityCount(map);//拿到数据的总条数
            map.put("totalCount",totalCount);
        }
        Map<String,Object> map1 = selectLimt(map);
        map1.put("list",service.queryPageCommunityList(map));
        return map1;
    }
    //删除小区信息  单个删除
    @GetMapping("deleteCommunity")
    public List<Map<String,Object>> deleteCommunity(@RequestParam int communityId){
        int count = service.deleteCommunity(communityId);
        return service.selectCommunity();
    }
    // 多选删除
    @GetMapping("mulDeleteCommunity")
    public List<Map<String,Object>> mulDeleteCommunity(@RequestParam Map<String,Object> map){

        Collection<Object> list =map.values();
        for (Object ID :list){
            int count = service.deleteCommunity(Integer.parseInt(ID.toString()));
        }
        return service.selectCommunity();
    }


    @GetMapping("updateCommunity")
    public void updateRoom(@RequestParam Map<String,Object> map){

        int count = service.updateCommunity(map);
    }

    @GetMapping("insertCommunity")
    public int insertCommunity(@RequestParam Map<String,Object> map){
        int count=service.insertCommunity(map);
        return 1;
    }

    //查询没有管理员管理room 所在小区的名字
    @GetMapping("queryNullSaleid")
    public List<Map<String,Object>>  queryNullSaleid(){
        return service.queryNullSaleid();
    };
    //查询小区的名字和id
    @GetMapping("queryCommunityIdAndName")
    public  List<Map<String,Object>> queryCommunityIdAndName(){
        return service.queryCommunityIdAndName();
    }

}
