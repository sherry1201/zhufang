package com.fhyTest.VueAndSpringboot.mapper;

import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public interface roomMapper {
    public List<Map<String,Object>> selectRoom();
    public int insertRoom(Map<String,Object> map);
//
    public int updateRoom(Map<String,Object> map);
//
    public int queryRoomCount(Map<String,Object> map);

    public List<Map<String,Object>> queryPageRoomList(Map<String,Object> map);
    //删除
    public int deleteRoom(int roomId);

    //给房间添加销售员ID
    public int updateSaleId(Map<String,Object> map );

    public int queryRoomInnerJoinHouseCount(Map<String,Object> map);

}
