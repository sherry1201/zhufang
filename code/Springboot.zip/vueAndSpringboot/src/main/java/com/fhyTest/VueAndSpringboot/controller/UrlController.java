package com.fhyTest.VueAndSpringboot.controller;

import com.fhyTest.VueAndSpringboot.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class UrlController extends BaseController{
    @Autowired
    private userService uService;

    @Autowired
    private questionService qService;

    @Autowired
    private roomService rService;

    @Autowired
    private houseService hService;

    @Autowired
    private communityService cService;



    @Autowired
    private collectService coService;

    @Autowired
    private JavaMailSender javaMailSender;

    //获取密保问题传到 注册页
    @GetMapping("userLogin")
    public ModelAndView userLogin(){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("list",qService.selectQuestion());
        return new ModelAndView("userLogin",map);
    }


    @GetMapping("updateUserDate")
    public String updateUserDate(HttpServletRequest request, HttpServletResponse response){
            return "updateUserDate";

    }

    @GetMapping("updateUserPassword")
    public ModelAndView updateUserPassword(){

        Map<String,Object> map = new HashMap<String,Object>();
        map.put("list",qService.selectQuestion());
        return new ModelAndView("updateUserPassword",map);

    }

    @GetMapping("forgetPassword")
    public ModelAndView forgetPassword(){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("list",qService.selectQuestion());
        return new ModelAndView("forgetPassword",map);
    }


    @GetMapping("roomList")
    public ModelAndView roomList(){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("pageIndex",1);
        map.put("pageSize",15);
        map.put("roomIshire","0");
        map.put("totalCount",rService.queryRoomCount(map));
        map = selectLimt(map);
        List<Map<String,Object>> list = rService.queryPageRoomList(map);
        for (int i=0;i<list.size();i++){
            list.get(i).put("roomUrl",img(list.get(i).get("roomUrl").toString()));
        }
        map.put("list",list);




        return new ModelAndView("roomList",map);
    }

    @GetMapping("roomData")
    public ModelAndView roomData(@RequestParam Map<String,Object> map){

        Map<String,Object> mapRoom = roomAllData(map);


        mapRoom.put("roomUrl",img(mapRoom.get("roomUrl").toString()));

        return new ModelAndView("roomData",mapRoom);
    }



    @GetMapping("tenement")
    public ModelAndView tenement(@RequestParam Map<String,Object> map,HttpSession session){

        List<Map<String,Object>> list = rService.queryPageRoomList(map);

        map.put("userHiredays",Integer.parseInt(map.get("userHiredays").toString())*30);
        map.put("userIshire",1);
        map.put("userHireroomid",map.get("roomId").toString());

        map.put("roomIshire",1);
        map.put("roomUserid",map.get("userId"));

        map.put("houseUserlist",list.get(0).get("houseUserlist").toString()+map.get("userId").toString()+",");

        String str1 [] = list.get(0).get("houseUserlist").toString().split(",");
        boolean sign = true;
        for(int i=0;i<str1.length;i++){
            if(str1[i].equals(map.get("userId"))){
                sign = false;
                break;
            }
        }
        if(sign){

            uService.updateUser(map);

            rService.updateRoom(map);

            hService.updateHouse(map);

        }

        Map<String,Object> mapRoom = roomAllData(map);
        mapRoom.put("roomUrl",img(mapRoom.get("roomUrl").toString()));


        List<Map<String,Object>> listu = uService.queryPageUserList(map);
        listu.get(0).put("userUrl",img( listu.get(0).get("userUrl").toString()));
        session.setAttribute("map", listu.get(0));


        return new ModelAndView("roomData",mapRoom);
    }

    @GetMapping("exixtRoom")
    public ModelAndView exixtRoom(@RequestParam Map<String,Object> map,HttpSession session){
        map.put("userHiredays","0");
        map.put("userIshire","0");
        map.put("userHireroomid","0");
        uService.updateUser(map);

        map.put("roomIshire","0");
        map.put("roomUserid","0");
        rService.updateRoom(map);

        List<Map<String,Object>> list = rService.queryPageRoomList(map);
        String str1 [] = list.get(0).get("houseUserlist").toString().split(",");
        StringBuffer str = new StringBuffer();
        for(int i=0;i<str1.length;i++){
            if (str1[i].equals(map.get("userId").toString())){
                continue;
            }
            str.append(str1[i]);
            str.append(",");
        }
        map.put("houseUserlist",str.toString());
        hService.updateHouse(map);


        Map<String,Object> mapRoom = roomAllData(map);
        mapRoom.put("roomUrl",img(mapRoom.get("roomUrl").toString()));

        List<Map<String,Object>> listu = uService.queryPageUserList(map);
        listu.get(0).put("userUrl",img( listu.get(0).get("userUrl").toString()));
        session.setAttribute("map", listu.get(0));

        return new ModelAndView("roomData",mapRoom);
    }


    @GetMapping("addDays")
    public ModelAndView addDays(@RequestParam Map<String,Object> map,HttpSession session){
        map.put("userHiredays",Integer.parseInt(map.get("userOldHiredays").toString())+Integer.parseInt(map.get("userHiredays").toString())*30);
        uService.updateUser(map);

        Map<String,Object> mapRoom = roomAllData(map);
        mapRoom.put("roomUrl",img(mapRoom.get("roomUrl").toString()));

        List<Map<String,Object>> listu = uService.queryPageUserList(map);
        listu.get(0).put("userUrl",img( listu.get(0).get("userUrl").toString()));
        session.setAttribute("map", listu.get(0));

        return new ModelAndView("roomData",mapRoom);
    }

    @GetMapping("myRoom")
    public ModelAndView myRoom(@RequestParam Map<String,Object> map){
        List<Map<String,Object>> listU = uService.queryPageUserList(map);
        map.put("roomId",Integer.parseInt(listU.get(0).get("userHireroomid").toString()));

        Map<String,Object> mapRoom = roomAllData(map);


        mapRoom.put("roomUrl",img(mapRoom.get("roomUrl").toString()));


        return new ModelAndView("roomData",mapRoom);

    }

    @GetMapping("delectCollect")
    public ModelAndView delectCollect(@RequestParam Map<String,Object> map){
        coService.collectDelete(map);
        Map<String,Object> mapRoom = roomAllData(map);
        mapRoom.put("roomUrl",img(mapRoom.get("roomUrl").toString()));

        return new ModelAndView("roomData",mapRoom);
    }

    @GetMapping("insetCollect")
    public ModelAndView insetCollect(@RequestParam Map<String,Object> map){
        List<Map<String,Object>> listCo = coService.queryPageCollectList(map);
        if(listCo.size()!=0){

        }else{
            coService.insertCollect(map);
        }

        Map<String,Object> mapRoom = roomAllData(map);
        mapRoom.put("roomUrl",img(mapRoom.get("roomUrl").toString()));

        return new ModelAndView("roomData",mapRoom);
    }

    @GetMapping("myCollect")
    public ModelAndView myCollect(@RequestParam Map<String,Object> map){
        Map<String,Object> mapDate = myAllCollect(map);

        return new ModelAndView("myCollect",mapDate);
    }


    @GetMapping("deleteManyCollect")
    public ModelAndView deleteCollect(@RequestParam Map<String,Object> map){
        String str1 [] = map.get("collectId").toString().split(",");
        for(int i=0;i<str1.length;i++) {
            coService.deleteCollect(Integer.parseInt(str1[i]));

        }

        map.remove("collectId");

        Map<String,Object> mapDate = myAllCollect(map);

        return new ModelAndView("myCollect",mapDate);
    }


    @GetMapping("first")
    public String first() {
        return "first";
    }

    @GetMapping("exit")
    public String exit(HttpSession session, SessionStatus sessionStatus){
        session.invalidate();
        sessionStatus.setComplete();
        return "redirect:/first";
    }

    @PostMapping("insertUser")
    public String insertUser1(@RequestParam Map<String,Object> map,HttpSession session, SessionStatus sessionStatus){
        int count=uService.insertUser(map);
        session.invalidate();
        sessionStatus.setComplete();
        return "redirect:/first";
    }

    @PostMapping("updateUser")
    public String updateUser1(@RequestParam Map<String,Object> map,HttpSession session){
        int count = uService.updateUser(map);
         List<Map<String,Object>> list = uService.queryPageUserList(map);

        list.get(0).put("userUrl",img( list.get(0).get("userUrl").toString()));
        session.setAttribute("map", list.get(0));
        return "redirect:/first";
    }

    @GetMapping("queryRoomInnerJoinHouse")
    public ModelAndView queryRoomInnerJoinHouse(@RequestParam Map<String,Object> map){

        map.put("roomIshire","0");


        if (map.get("pageIndex") != null && map.get("pageSize") != null) {
            int totalCount = rService.queryRoomInnerJoinHouseCount(map);//拿到数据的总条数
            map.put("totalCount",totalCount);

        }
        List<Map<String,Object>> list = rService.queryPageRoomList(map);
        map= selectLimt(map);
        map.put("list",list);
        for (int i=0;i<list.size();i++){
            list.get(i).put("roomUrl",img(list.get(i).get("roomUrl").toString()));
        }


        return new ModelAndView("roomList",map);
    }

}
