package com.fhyTest.VueAndSpringboot.mapper;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public interface adminMapper {
  //返回管理员集合
  public List<Map<String,Object>> queryAdmin();

  public int deleteAdmin(int adminId);

  public int insertAdmin(Map<String,Object> map);

  public int updateAdmin(Map<String,Object> map);

  public int queryAdminCount(Map<String,Object> map);

  public Map<String,Object> queryPageAdminList(Map<String,Object> map);

}
