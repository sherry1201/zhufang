package com.fhyTest.VueAndSpringboot.mapper;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface questionMapper{
    public List<Map<String,Object>> selectQuestion();
}
