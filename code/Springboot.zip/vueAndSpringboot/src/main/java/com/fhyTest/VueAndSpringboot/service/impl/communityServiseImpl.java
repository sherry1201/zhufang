package com.fhyTest.VueAndSpringboot.service.impl;

import com.fhyTest.VueAndSpringboot.mapper.communityMapper;
import com.fhyTest.VueAndSpringboot.mapper.userMapper;
import com.fhyTest.VueAndSpringboot.service.communityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class communityServiseImpl implements communityService {
    @Autowired
    communityMapper mapper;

    @Override
    public List<Map<String,Object>> selectCommunity() {
        return mapper.selectCommunity();
    }
    @Override
    public int insertCommunity(Map<String,Object> map) {
        return mapper.insertCommunity(map);
    }

    @Override
    public int updateCommunity(Map<String,Object> map) {
        return mapper.updateCommunity(map);
    }

    @Override
    public int queryCommunityCount(Map<String,Object> map) {
        return mapper.queryCommunityCount(map);
    }

    @Override
    public List<Map<String,Object>> queryPageCommunityList(Map<String,Object> map) {
        return mapper.queryPageCommunityList(map);
    }
//
    @Override
    public int deleteCommunity(int communityId) {
        return mapper.deleteCommunity(communityId);
    }

    @Override
    public List<Map<String,Object>> queryNullSaleid() {
        return mapper.queryNullSaleid();
    }

    @Override
    public List<Map<String, Object>> queryCommunityIdAndName() {
        return mapper.queryCommunityIdAndName();
    }
}
