package com.fhyTest.VueAndSpringboot.controller;

//import com.fhyTest.VueAndSpringboot.service.communityService;
import com.fhyTest.VueAndSpringboot.service.roomService;
import com.fhyTest.VueAndSpringboot.service.saleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class saleController extends BaseController{
    @Autowired
    private saleService service;
    @Autowired
    private roomService rservice;

//    @GetMapping("selectSale")
//    public Map<String,Object> selectSale(@RequestParam Map<String,Object> map){
//        System.out.println(map);
//        Map<String,Object> map1 = selectLimt(map);
//        map1.put("list",service.queryPageSaleList(map));
//        return map1;
//    }

    @GetMapping("querySale")
    public Map<String,Object> querySale(@RequestParam Map<String,Object> map){
//        提供数据库数据
//        Map<String,Object> map = new HashMap<String,Object>();
//        map.put("saleName","王五");
//        map.put("salePhone","16611119999");
//        map.put("saleUrl","E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg");
//        map.put("saleRoomid","1,2,3");
//        for (int i = 0 ;i <100 ; i++){
//            int count = service.insertSale(map);
//        }
        if(map.size()!=0){
            int totalCount = service.querySaleCount(map);//拿到数据的总条数
            map.put("totalCount",totalCount);
        }
        Map<String,Object> map1 = selectLimt(map);
        map1.put("list",service.queryPageSaleList(map));
        return map1;
    }
    //删除销售员信息  单个删除
    @GetMapping("deleteSale")
    public List<Map<String,Object>> deleteRoom(@RequestParam int saleId){
        int count = service.deleteSale(saleId);
        return service.selectSale();
    }
    // 多选删除
    @GetMapping("mulDeleteSale")
    public List<Map<String,Object>> mulDeleteSale(@RequestParam Map<String,Object> map){
        Collection<Object> list =map.values();
        for (Object ID :list){
            int count = service.deleteSale(Integer.parseInt(ID.toString()));
        }
        return service.selectSale();
    }

    @GetMapping("updateSale")
    public String updateRoom(@RequestParam Map<String,Object> map){
         System.out.println(map);
        int count = service.updateSale(map);
        System.out.println(count);
        return "index";
    }
//    //销售员证件的上传
//    @PostMapping("uploadSale")
//    public String uploadSale(@RequestParam("file") MultipartFile file){
//        return uploadFile(file);
//    }



    @GetMapping("insertSale")
    public String insertSale(@RequestParam Map<String,Object> map){
        String[] str = map.get("saleRoomid").toString().split(",");
        int count = service.insertSale(map);
        int saleId = service.querySaleId(map.get("saleRoomid").toString());
        HashMap<String,Object> m = new HashMap<String, Object>();
        m.put("roomSaleid",saleId);
        for (int i = 0 ; i <str.length; i++){
            m.put("roomId",Integer.parseInt(str[i]));
            int c = rservice.updateSaleId(m);
        }
        return "sds";
    }


    //添加房屋是 选择需要管理员的Id和姓名
    @GetMapping("querySaleNameAndId")
    public List<Map<String,Object>> querySaleNameAndId(){
        return  service.querySaleNameAndId();
    }

    @PostMapping("saleUpload")
    public String upload(@RequestParam("file") MultipartFile file){
        String fileName=file.getOriginalFilename();//取得文件的名字
        String filePath="/d:/upload/";//目标上传的路径
        File d=new File(filePath+fileName);
        try{
            file.transferTo(d);
        }catch (Exception e){
        }
        return "index";
    }

}
