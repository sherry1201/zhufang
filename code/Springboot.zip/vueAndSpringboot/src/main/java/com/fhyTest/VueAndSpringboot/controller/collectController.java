package com.fhyTest.VueAndSpringboot.controller;

import com.fhyTest.VueAndSpringboot.service.collectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.List;
import java.util.Map;

@RestController

public class collectController extends BaseController{
    @Autowired
    private collectService service;


    @GetMapping("queryCollect")
    public Map<String,Object> queryCollect(@RequestParam Map<String,Object> map){
////        提供数据库数据
//        Map<String,Object> map = new HashMap<String,Object>();
//        map.put("CollectAdress","武汉市汉阳区汉阳大道磨山小区");
//        map.put("CollectSubwayfirst","三号线");
//        map.put("CollectSubwaysecond","宗关");
//        map.put("CollectSubwaydistence",1000);
//        map.put("CollectAreafirst","汉阳");
//        map.put("CollectAreasecond","王家湾");
//        map.put("CollectSize",90000);
//        map.put("CollectIslift",1);
//        map.put("CollectGreensize",30);
//        map.put("CollectParkinglotsize",10000);
//        map.put("CollectParkinglotcost",200);
//        map.put("CollectPropertyphone","001-1112222-111");
//        for (int i = 0 ;i <500 ; i++){
//            int count = service.insertCollect(map);
//        }
        if(map.size()!=0){
            int totalCount = service.queryCollectCount(map);//拿到数据的总条数
            map.put("totalCount",totalCount);
        }
        Map<String,Object> map1 = selectLimt(map);
        map1.put("list",service.queryPageCollectList(map));
        return map1;
    }
    //删除小区信息  单个删除
    @GetMapping("deleteCollect")
    public List<Map<String,Object>> deleteCollect(@RequestParam int CollectId){
        int count = service.deleteCollect(CollectId);
        return service.queryCollect();
    }
    // 多选删除
    @GetMapping("mulDeleteCollect")
    public List<Map<String,Object>> mulDeleteCollect(@RequestParam Map<String,Object> map){
        System.out.println(map.toString());
        Collection<Object> list =map.values();
        for (Object ID :list){
            int count = service.deleteCollect(Integer.parseInt(ID.toString()));
        }
        return service.queryCollect();
    }


    @GetMapping("updateCollect")
    public String updateRoom(@RequestParam Map<String,Object> map){
        System.out.println(map);
        int count = service.updateCollect(map);
        System.out.println(count);
        return "index";
    }

    @GetMapping("insertCollect")
    public int insertCollect(@RequestParam Map<String,Object> map){
        int count=service.insertCollect(map);
        return 1;
    }

}