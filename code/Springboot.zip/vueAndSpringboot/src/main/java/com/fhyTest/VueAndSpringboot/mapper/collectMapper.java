package com.fhyTest.VueAndSpringboot.mapper;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository

public interface collectMapper {

    public List<Map<String,Object>> queryCollect();

    public int deleteCollect(int adminId);

    public int insertCollect(Map<String,Object> map);

    public int updateCollect(Map<String,Object> map);

    public int queryCollectCount(Map<String,Object> map);

    public List<Map<String,Object>> queryPageCollectList(Map<String,Object> map);

    public void collectDelete(Map<String,Object> map);

}
