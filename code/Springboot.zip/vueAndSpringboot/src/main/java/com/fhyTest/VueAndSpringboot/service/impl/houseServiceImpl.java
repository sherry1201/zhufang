package com.fhyTest.VueAndSpringboot.service.impl;

import com.fhyTest.VueAndSpringboot.mapper.houseMapper;

import com.fhyTest.VueAndSpringboot.service.houseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class houseServiceImpl implements houseService {

    @Autowired
    private houseMapper mapper;

    @Override
    public List<Map<String, Object>> selectHouse() {
        return mapper.selectHouse();
    }

    @Override
    public int insertHouse(Map<String, Object> map) {
        return mapper.insertHouse(map);
    }

    @Override
    public int updateHouse(Map<String, Object> map) {
        return mapper.updateHouse(map);
    }

    @Override
    public int queryHouseCount(Map<String, Object> map) {
        return mapper.queryHouseCount(map);
    }

    @Override
    public List<Map<String, Object>> queryPageHouseList(Map<String, Object> map) {
        return mapper.queryPageHouseList(map);
    }
    @Override
    public int deleteHouse(int houseId) {
        return mapper.deleteHouse(houseId);
    }

    @Override
    public List<Map<String, Object>> queryHouseNameAndId(int communityId) {
        return mapper.queryHouseNameAndId(communityId);
    }
}
