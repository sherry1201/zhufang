package com.fhyTest.VueAndSpringboot.service.impl;

import com.fhyTest.VueAndSpringboot.mapper.userMapper;
import com.fhyTest.VueAndSpringboot.service.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class userServiceImpl implements userService {
   @Autowired
   userMapper mapper;


    @Override
    public List<Map<String, Object>> selectUser() {
        return mapper.selectUser();
    }

    @Override
    public int insertUser(Map<String, Object> map) {
        return mapper.insertUser(map);
    }

    @Override
    public int updateUser(Map<String, Object> map) {
        return mapper.updateUser(map);
    }

    @Override
    public int queryUserCount(Map<String, Object> map) {
        return mapper.queryUserCount(map);
    }

    @Override
    public List<Map<String, Object>> queryPageUserList(Map<String, Object> map) {
        return mapper.queryPageUserList(map);
    }

    @Override
    public int deleteUser(int userId) {
        return mapper.deleteUser(userId);
    }

    @Override
    public List<Map<String, Object>> queryUserAndQuestion(Map<String, Object> map) {
        return mapper.queryUserAndQuestion (map);
                                                                                     }

    @Override
    public List<Map<String, Object>> queryUserAndRoom(Map<String, Object> map) {
        return mapper.queryUserAndRoom(map);
    }
}
