package com.fhyTest.VueAndSpringboot.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class toolController extends BaseController{
  //上传
  @PostMapping("upload")
  public String uploadSale(@RequestParam("file") MultipartFile file){

    return uploadFile(file);
  }

  @PostMapping("upload1")
  public String upload(@RequestParam("file") MultipartFile file){
    return uploadFile1(file);
  }


}
