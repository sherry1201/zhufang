package com.fhyTest.VueAndSpringboot.controller;
import com.fhyTest.VueAndSpringboot.service.communityService;
import com.fhyTest.VueAndSpringboot.service.roomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class roomCotroller extends BaseController{

    @Autowired
    private roomService service;


    @GetMapping("queryRoom")
    public Map<String,Object> queryRoom(@RequestParam Map<String,Object> map){

        System.out.println(map.toString());


       if (map.get("pageIndex") != null && map.get("pageSize") != null) {
            int totalCount = service.queryRoomCount(map);//拿到数据的总条数
            map.put("totalCount",totalCount);
        }


        Map<String,Object> map1 = selectLimt(map);
        map1.put("list",service.queryPageRoomList(map));
        return map1;
    }

    //删除房源信息  单个删除
    @GetMapping("deleteRoom")
    public List<Map<String,Object>> deleteRoom(@RequestParam int roomId){
        int count = service.deleteRoom(roomId);
        return service.selectRoom();
    }
    // 多选删除
    @GetMapping("mulDeleteRoom")
    public List<Map<String,Object>> mulDeleteRoom(@RequestParam Map<String,Object> map){
        Collection<Object> list =map.values();
        for (Object ID :list){
            int count = service.deleteRoom(Integer.parseInt(ID.toString()));
        }
        return service.selectRoom();
    }

    //修改
    @GetMapping("updateRoom")
    public void updateRoom(@RequestParam Map<String,Object> map){
        int count = service.updateRoom(map);
    }

    @GetMapping("insertRoom")
    public void insertRoom(@RequestParam Map<String,Object> map){
        int count=service.insertRoom(map);
    }





}
