package com.fhyTest.VueAndSpringboot.mapper;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface communityMapper {
    public List<Map<String,Object>> selectCommunity();

    public int deleteCommunity(int communityId);
    public int insertCommunity(Map<String,Object> map);
//
    public int updateCommunity(Map<String,Object> map);
//
    public int queryCommunityCount(Map<String,Object> map);
//
    public List<Map<String,Object>> queryPageCommunityList(Map<String,Object> map);
    //查询没有管理员管理room 所在小区的名字
    public List<Map<String,Object>> queryNullSaleid();
    //查询小区的名字和id
    public List<Map<String,Object>> queryCommunityIdAndName();
}
