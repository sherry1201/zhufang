/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50719
 Source Host           : localhost:3306
 Source Schema         : lessonproject

 Target Server Type    : MySQL
 Target Server Version : 50719
 File Encoding         : 65001

 Date: 15/06/2022 21:10:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_admin
-- ----------------------------
DROP TABLE IF EXISTS `tb_admin`;
CREATE TABLE `tb_admin`  (
  `admin_id` int(255) NOT NULL AUTO_INCREMENT,
  `admin_account` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `admin_password` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `admin_phone` bigint(255) NOT NULL,
  PRIMARY KEY (`admin_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_czech_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_admin
-- ----------------------------
INSERT INTO `tb_admin` VALUES (1, 'admin', '123456', 166760571865);
INSERT INTO `tb_admin` VALUES (2, 'admin1', '123456789', 16676022222);
INSERT INTO `tb_admin` VALUES (3, 'admin1', '123456789', 16676022222);
INSERT INTO `tb_admin` VALUES (4, 'admin1', '123456789', 16676022222);
INSERT INTO `tb_admin` VALUES (5, 'admin2', '123456', 16676057188);
INSERT INTO `tb_admin` VALUES (6, 'lucky', 'asdfghj', 16677777777);

-- ----------------------------
-- Table structure for tb_collect
-- ----------------------------
DROP TABLE IF EXISTS `tb_collect`;
CREATE TABLE `tb_collect`  (
  `collect_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NULL DEFAULT NULL,
  `user_id` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`collect_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 32 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_collect
-- ----------------------------
INSERT INTO `tb_collect` VALUES (28, 122, 77);
INSERT INTO `tb_collect` VALUES (29, 72, 77);
INSERT INTO `tb_collect` VALUES (30, 85, 77);
INSERT INTO `tb_collect` VALUES (31, 120, 77);

-- ----------------------------
-- Table structure for tb_community
-- ----------------------------
DROP TABLE IF EXISTS `tb_community`;
CREATE TABLE `tb_community`  (
  `community_id` int(11) NOT NULL AUTO_INCREMENT,
  `community_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `community_adress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `community_subwayfirst` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `community_subwaysecond` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `community_subwaydistence` int(255) NOT NULL,
  `community_areafirst` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `community_areasecond` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `community_size` int(255) NOT NULL,
  `community_islift` int(255) NOT NULL DEFAULT 1,
  `community_greensize` int(255) NOT NULL,
  `community_parkinglotsize` int(255) NOT NULL,
  `community_parkinglotcost` int(11) NOT NULL,
  `community_propertyphone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `community_longitude` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `community_latitude` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`community_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 503 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_community
-- ----------------------------
INSERT INTO `tb_community` VALUES (1, '保利华都', '武汉市洪山区保利华都', '5号线', '杨家湾', 899, '江岸', '永清街道', 80000, 1, 30, 1000, 200, '001-1112222-111', '114.4297807050', ' 30.4287806047');
INSERT INTO `tb_community` VALUES (18, '磨山小区', '武汉市汉阳区汉阳大道磨山小区', '3号线', '宗关', 1000, '汉阳', '王家湾', 90000, 1, 30, 10000, 200, '001-1112222-111', NULL, NULL);
INSERT INTO `tb_community` VALUES (22, '汤臣一品', '武汉市汉阳区汉阳大道磨山小区', '3号线', '宗关', 1000, '汉阳', '王家湾', 90000, 1, 30, 10000, 200, '001-1112222-111', NULL, NULL);
INSERT INTO `tb_community` VALUES (55, '梅苑小区', '武汉市汉阳区汉阳大道磨山小区', '3号线', '宗关', 1000, '汉阳', '王家湾', 90000, 1, 30, 10000, 200, '001-1112222-111', NULL, NULL);
INSERT INTO `tb_community` VALUES (502, '城市印象', '武汉市汉阳区城市印象', '3号线', '王家湾', 900, '汉阳', '五里墩街道', 80000, 1, 20, 12000, 300, '0222111111', NULL, NULL);

-- ----------------------------
-- Table structure for tb_house
-- ----------------------------
DROP TABLE IF EXISTS `tb_house`;
CREATE TABLE `tb_house`  (
  `house_id` int(11) NOT NULL AUTO_INCREMENT,
  `house_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `house_size` int(255) NOT NULL,
  `house_userlist` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `house_floor` int(255) NOT NULL,
  `house_layout` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `house_salespersonid` int(11) NULL DEFAULT NULL,
  `house_communityid` int(11) NOT NULL,
  PRIMARY KEY (`house_id`) USING BTREE,
  INDEX `houser_communityid`(`house_communityid`) USING BTREE,
  CONSTRAINT `tb_house_ibfk_1` FOREIGN KEY (`house_communityid`) REFERENCES `tb_community` (`community_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1003 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_house
-- ----------------------------
INSERT INTO `tb_house` VALUES (1, '五栋1402', 133, ',77', 14, '三室', 1, 1);
INSERT INTO `tb_house` VALUES (11, '五栋1101', 120, '1,2,3', 11, '三室一厅', 436, 18);
INSERT INTO `tb_house` VALUES (12, '五栋1902', 120, '1,2,3', 19, '三室一厅', 436, 55);
INSERT INTO `tb_house` VALUES (13, '五栋2002', 120, '1,2,3', 20, '三室一厅', 436, 55);
INSERT INTO `tb_house` VALUES (14, '五栋2001', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (29, '五栋2002', 120, '1,2,3', 20, '三室一厅', 22, 1);
INSERT INTO `tb_house` VALUES (30, '五栋1501', 120, '1,2,3', 15, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (31, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 1);
INSERT INTO `tb_house` VALUES (32, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (33, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (34, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (35, '五栋2309', 120, '78,79,80,77,', 20, '三室一厅', 22, 1);
INSERT INTO `tb_house` VALUES (36, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (37, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (38, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (39, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (40, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (41, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (42, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (43, '五栋2302', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (44, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (45, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (46, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (47, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (48, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (49, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (50, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (51, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (52, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (53, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (54, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (55, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (56, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (57, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (58, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (59, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (60, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (61, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (62, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (63, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (64, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (65, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (66, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (67, '', 120, '1,2,3', 20, '三室一厅', 22, 55);
INSERT INTO `tb_house` VALUES (1002, '五栋2302', 133, NULL, 23, '二室二厅二卫', 80, 18);

-- ----------------------------
-- Table structure for tb_question
-- ----------------------------
DROP TABLE IF EXISTS `tb_question`;
CREATE TABLE `tb_question`  (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `question_content` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`question_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_question
-- ----------------------------
INSERT INTO `tb_question` VALUES (1, '你妈妈的名字？');
INSERT INTO `tb_question` VALUES (2, '你爸爸的名字？');
INSERT INTO `tb_question` VALUES (3, '你的小学校名');
INSERT INTO `tb_question` VALUES (4, '你最喜欢的老师');
INSERT INTO `tb_question` VALUES (5, '你喜欢的明星');

-- ----------------------------
-- Table structure for tb_room
-- ----------------------------
DROP TABLE IF EXISTS `tb_room`;
CREATE TABLE `tb_room`  (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_num` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `room_size` double(255, 0) NOT NULL,
  `room_rent` int(255) NOT NULL,
  `room_hiretype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `room_face` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `room_describe` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '暂无简介',
  `room_item` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `room_ishire` int(255) NOT NULL DEFAULT 0,
  `room_url` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `room_houseid` int(11) NOT NULL,
  `room_saleid` int(11) NULL DEFAULT NULL,
  `room_userid` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`room_id`) USING BTREE,
  INDEX `house-room`(`room_houseid`) USING BTREE,
  CONSTRAINT `house-room` FOREIGN KEY (`room_houseid`) REFERENCES `tb_house` (`house_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 205 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_room
-- ----------------------------
INSERT INTO `tb_room` VALUES (72, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\76ee66de4dc057e82ea9aedfcc95b52f .jpeg', 35, 436, 77);
INSERT INTO `tb_room` VALUES (73, '01', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 35, 2, NULL);
INSERT INTO `tb_room` VALUES (74, '03', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 35, 1, NULL);
INSERT INTO `tb_room` VALUES (75, '04', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 35, 2, NULL);
INSERT INTO `tb_room` VALUES (76, '03', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 2, NULL);
INSERT INTO `tb_room` VALUES (77, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 2, NULL);
INSERT INTO `tb_room` VALUES (78, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 2, NULL);
INSERT INTO `tb_room` VALUES (79, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 3, NULL);
INSERT INTO `tb_room` VALUES (80, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 3, NULL);
INSERT INTO `tb_room` VALUES (81, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 3, NULL);
INSERT INTO `tb_room` VALUES (82, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 3, NULL);
INSERT INTO `tb_room` VALUES (83, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 3, NULL);
INSERT INTO `tb_room` VALUES (84, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (85, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 11, 430, NULL);
INSERT INTO `tb_room` VALUES (86, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 29, 433, NULL);
INSERT INTO `tb_room` VALUES (87, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (88, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 13, 436, NULL);
INSERT INTO `tb_room` VALUES (89, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 105, NULL);
INSERT INTO `tb_room` VALUES (90, '01', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 31, 401, NULL);
INSERT INTO `tb_room` VALUES (91, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (92, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (93, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (94, '01', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (95, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (96, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (97, '01', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 429, NULL);
INSERT INTO `tb_room` VALUES (98, '04', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 431, NULL);
INSERT INTO `tb_room` VALUES (99, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (100, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (101, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (102, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (103, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (104, '02', 10, 900, '合租', '南', '适合第一次租房的人租', '采光好', 1, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (120, '02', 13, 700, '合租', '南', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 424, NULL);
INSERT INTO `tb_room` VALUES (121, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 11, 425, NULL);
INSERT INTO `tb_room` VALUES (122, '02', 13, 900, '合租', '西', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 12, 76, NULL);
INSERT INTO `tb_room` VALUES (123, '02', 24, 1000, '合租', '东', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 426, NULL);
INSERT INTO `tb_room` VALUES (124, '02', 24, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (125, '02', 42, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (126, '02', 34, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (127, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (128, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (129, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (130, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 429, NULL);
INSERT INTO `tb_room` VALUES (131, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 429, NULL);
INSERT INTO `tb_room` VALUES (132, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 430, NULL);
INSERT INTO `tb_room` VALUES (133, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\17b79a9b29034d305ed68523ef94bad2.jpeg', 1, 430, NULL);
INSERT INTO `tb_room` VALUES (134, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 430, NULL);
INSERT INTO `tb_room` VALUES (135, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 431, NULL);
INSERT INTO `tb_room` VALUES (136, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (137, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (138, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (139, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (140, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (141, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 425, NULL);
INSERT INTO `tb_room` VALUES (142, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (143, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (144, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (145, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (146, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (147, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (148, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (149, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (150, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (151, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (152, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (153, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (154, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (155, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (156, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (157, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (158, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (159, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (160, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (161, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (162, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (163, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (164, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (165, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (166, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (167, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (168, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (169, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (170, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (171, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (172, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (173, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 12, NULL, NULL);
INSERT INTO `tb_room` VALUES (174, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (175, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (176, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (177, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (178, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (179, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (180, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (181, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (182, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (183, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (184, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (185, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (186, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (187, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (188, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (189, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (190, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (191, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (192, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (193, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (194, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (195, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (196, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (197, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, NULL, NULL);
INSERT INTO `tb_room` VALUES (198, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 436, NULL);
INSERT INTO `tb_room` VALUES (199, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 436, NULL);
INSERT INTO `tb_room` VALUES (200, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 436, NULL);
INSERT INTO `tb_room` VALUES (201, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 433, NULL);
INSERT INTO `tb_room` VALUES (202, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 433, NULL);
INSERT INTO `tb_room` VALUES (203, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 433, NULL);
INSERT INTO `tb_room` VALUES (204, '02', 13, 1000, '合租', '北', '适合第一次租房的人租', '性价比', 0, 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', 1, 430, NULL);

-- ----------------------------
-- Table structure for tb_sale
-- ----------------------------
DROP TABLE IF EXISTS `tb_sale`;
CREATE TABLE `tb_sale`  (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `sale_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `sale_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `sale_roomid` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sale_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 437 CHARACTER SET = utf8 COLLATE = utf8_czech_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_sale
-- ----------------------------
INSERT INTO `tb_sale` VALUES (76, '王五', '16611119999', 'E:\\html_workplace\\lessonproject\\srcassets\\215136lc3iw364d22ia9w2.jpg', '1,2,3');
INSERT INTO `tb_sale` VALUES (77, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (78, '王五', '16611119999', 'E:\\html_workplace\\lessonproject\\srcassets\\710214916.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (79, '王五', '16611119999', 'E:\\html_workplace\\lessonproject\\srcassets\\181642sngt5m0tbztl2u5g.jpg', '1,2,3');
INSERT INTO `tb_sale` VALUES (80, '方羽', '16611119999', 'E:\\html_workplace\\lessonproject\\srcassets\\e0cd0ab3ea53119d167d8fadb9ad01e7.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (81, '王五', '16611119999', 'E:\\html_workplace\\lessonproject\\srcassets\\707163241.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (82, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (83, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (89, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (90, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (91, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (93, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (94, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (95, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (200, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (201, '王五', '16611119999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (208, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (209, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (210, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (211, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (212, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (213, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (214, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (215, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (216, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (217, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (218, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (223, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (224, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (225, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (299, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (300, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (301, '方羽', '19910001111', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (310, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (311, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (312, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (313, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (356, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (357, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (358, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (359, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (360, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (361, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (362, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (363, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (364, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (365, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (366, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (367, '林霸天', '13322229999', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '1,2,3');
INSERT INTO `tb_sale` VALUES (402, 'wang', '18887776666', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '86,84,87,89,90');
INSERT INTO `tb_sale` VALUES (403, 'wang', '18887776666', 'E:\\html_workplace\\lessonproject\\srcassets\\181642sngt5m0tbztl2u5g.jpg', '86,84,87,89,90');
INSERT INTO `tb_sale` VALUES (404, 'Wang', '18899996666', 'E:\\html_workplace\\lessonproject\\srcassets\\061223xrnhdje123hoojm3.jpg', '86,84,87,89,90,91');
INSERT INTO `tb_sale` VALUES (405, 'Wang', '18899996666', 'E:\\html_workplace\\lessonproject\\srcassets\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '86,84,87,89,90,91');
INSERT INTO `tb_sale` VALUES (406, 'Wang', '18899996666', 'E:\\html_workplace\\lessonproject\\srcassets\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '86,84,87,89,90,91');
INSERT INTO `tb_sale` VALUES (407, 'www', '19988889999', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '84,86,87,89,90,91');
INSERT INTO `tb_sale` VALUES (408, '王', '19988886666', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '91,89,87,86,84');
INSERT INTO `tb_sale` VALUES (409, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '86,84,87,89,91');
INSERT INTO `tb_sale` VALUES (410, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '86,84,87,89,91');
INSERT INTO `tb_sale` VALUES (411, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\215136lc3iw364d22ia9w2.jpg', '84,87,86');
INSERT INTO `tb_sale` VALUES (412, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '87,86');
INSERT INTO `tb_sale` VALUES (413, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '87,86');
INSERT INTO `tb_sale` VALUES (414, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\710214917.jpeg', '87,86,84');
INSERT INTO `tb_sale` VALUES (415, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '86,84');
INSERT INTO `tb_sale` VALUES (416, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\181642sngt5m0tbztl2u5g.jpg', '84');
INSERT INTO `tb_sale` VALUES (417, 'Wangle', '18899998888', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '86,84,87,89');
INSERT INTO `tb_sale` VALUES (418, 'W昂', '18877776666', 'E:\\html_workplace\\lessonproject\\srcassets\\5f957c9830d088cbd6194ac42e147581.jpeg', '86,84,87,89');
INSERT INTO `tb_sale` VALUES (419, 'W昂', '19988887777', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '86,84,87,89');
INSERT INTO `tb_sale` VALUES (420, 'W昂', '19988887777', 'E:\\html_workplace\\lessonproject\\srcassets\\215136lc3iw364d22ia9w2.jpg', '143,142,140');
INSERT INTO `tb_sale` VALUES (421, 'W昂', '19988887777', 'E:\\html_workplace\\lessonproject\\srcassets\\215136lc3iw364d22ia9w2.jpg', '143,140');
INSERT INTO `tb_sale` VALUES (422, 'W昂', '19988887777', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '194,193,204');
INSERT INTO `tb_sale` VALUES (423, 'W昂', '19988887777', 'E:\\html_workplace\\lessonproject\\srcassets\\5aa7dc9aa4794fc24a3806ecea6eb944.jpeg', '194,193');
INSERT INTO `tb_sale` VALUES (424, '肖峥', '18877776666', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '93,92,91,87,84,95,96,99,100,101,102,103,104,120');
INSERT INTO `tb_sale` VALUES (425, 'wangaaa', '18888887777', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '94,121,122,124,125,126,127,128,129,141,140');
INSERT INTO `tb_sale` VALUES (426, 'aaaaa', '16666666666', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '97,123,130,131');
INSERT INTO `tb_sale` VALUES (427, 'aaaaa', '16666666666', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '97');
INSERT INTO `tb_sale` VALUES (428, 'aaaaa', '16666666666', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', '97');
INSERT INTO `tb_sale` VALUES (429, 'aaaaa', '16666666666', 'E:\\html_workplace\\lessonproject\\srcassets\\5f957c9830d088cbd6194ac42e147581.jpeg', '97,130,131');
INSERT INTO `tb_sale` VALUES (430, 'aaaaa', '17788889999', 'E:\\html_workplace\\lessonproject\\srcassets\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '132,133,134,85,204');
INSERT INTO `tb_sale` VALUES (431, 'wang', '17777766665', 'E:\\html_workplace\\lessonproject\\srcassets\\710214919.jpeg', '135,98');
INSERT INTO `tb_sale` VALUES (432, 'wangaa', '17766668888', 'E:\\html_workplace\\lessonproject\\srcassets\\22d710611d10df341dff2e280bb5ea84.jpeg', 'undefined,203,202');
INSERT INTO `tb_sale` VALUES (433, 'wangaa', '17766668888', 'E:\\html_workplace\\lessonproject\\srcassets\\5aa7dc9aa4794fc24a3806ecea6eb944.jpeg', '203,202,201,86');
INSERT INTO `tb_sale` VALUES (434, 'wangaa', '17766668888', 'E:\\html_workplace\\lessonproject\\srcassets\\5aa7dc9aa4794fc24a3806ecea6eb944.jpeg', '');
INSERT INTO `tb_sale` VALUES (435, 'aaaaaaa', '17766669999', 'D:\\lessonproject\\lessonproject\\src\\assets\\6fe14fc6-7f69-4a05-a463-94fbf7d8f6d6.jpg', '');
INSERT INTO `tb_sale` VALUES (436, 'fdd', '18877776666', 'D:\\lessonproject\\lessonproject\\src\\assets\\6fe14fc6-7f69-4a05-a463-94fbf7d8f6d6.jpg', '88,200,198,199');

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user`  (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `user_age` int(255) NOT NULL,
  `user_sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `user_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NULL DEFAULT NULL,
  `user_account` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `user_password` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `user_mail` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NULL DEFAULT NULL,
  `user_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NOT NULL,
  `user_ishire` int(255) NOT NULL DEFAULT 0,
  `user_hiredays` int(255) NULL DEFAULT NULL,
  `user_hireroomid` int(255) NULL DEFAULT NULL,
  `user_questionid` int(11) NULL DEFAULT NULL,
  `user_questionanswer` varchar(255) CHARACTER SET utf8 COLLATE utf8_czech_ci NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 303 CHARACTER SET = utf8 COLLATE = utf8_czech_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES (77, 'wss', 33, '女', 'D:\\lessonproject\\lessonproject\\src\\assets\\4b1fd31b-dea1-4718-8bf9-001fa931527e.jpg', 'wss', 'aiyyy', '203204438@qq.com', '15107272278', 1, 180, 72, 1, '123456');
INSERT INTO `tb_user` VALUES (78, '李四', 28, '', 'D:\\lessonproject\\lessonproject\\src\\assets\\6fe14fc6-7f69-4a05-a463-94fbf7d8f6d6.jpg', '12', '33', NULL, '17799991111', 1, 11, 73, NULL, NULL);
INSERT INTO `tb_user` VALUES (79, '李sdfsdfsdfa', 22, '', 'D:\\lessonproject\\lessonproject\\src\\assets\\6fe14fc6-7f69-4a05-a463-94fbf7d8f6d6.jpg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 74, NULL, NULL);
INSERT INTO `tb_user` VALUES (80, '李sdfsdf', 56, '', 'D:\\lessonproject\\lessonproject\\src\\assets\\6fe14fc6-7f69-4a05-a463-94fbf7d8f6d6.jpg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 75, NULL, NULL);
INSERT INTO `tb_user` VALUES (81, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (82, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (83, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (84, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (85, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (86, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (87, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (88, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (89, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (90, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (91, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (92, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (93, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (94, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (95, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (96, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (97, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (98, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (99, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (100, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (101, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (102, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (103, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (104, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (105, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (106, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (107, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (108, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (109, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (110, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (111, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (112, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (113, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (114, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (115, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (116, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (117, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (118, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (119, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (120, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (121, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (122, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (123, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (124, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (125, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (126, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (127, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (128, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (129, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (130, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (131, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (132, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (133, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (134, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (135, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (136, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (137, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (138, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (139, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (140, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (141, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (142, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (143, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (144, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (145, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (146, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (147, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (148, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (149, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (150, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (151, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (152, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (153, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (154, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (155, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (156, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (157, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (158, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (159, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (160, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (161, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (162, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (163, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (164, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (165, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (166, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (167, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (168, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (169, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (170, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (171, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (172, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (173, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (174, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (175, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (176, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (177, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (178, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (179, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (180, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (181, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (182, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (183, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (184, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (185, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (186, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (187, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (188, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (189, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (190, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (191, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (192, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (193, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (194, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (195, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (196, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (197, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (198, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (199, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (200, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (201, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (202, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (203, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (204, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (205, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (206, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (207, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (208, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (209, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (210, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (211, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (212, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (213, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (214, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (215, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (216, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (217, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (218, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (219, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (220, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (221, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (222, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (223, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (224, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (225, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (226, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (227, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (228, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (229, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (230, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (231, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (232, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (233, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (234, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (235, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (236, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (237, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (238, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (239, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (240, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (241, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (242, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (243, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (244, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (245, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (246, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (247, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (248, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (249, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (250, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (251, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (252, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (253, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (254, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (255, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (256, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (257, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (258, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (259, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (260, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (261, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (262, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (263, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (264, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (265, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (266, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (267, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (268, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (269, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (270, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (271, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (272, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (273, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (274, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (275, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (276, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (277, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (278, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (279, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (280, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (281, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (282, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (283, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (284, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (285, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (286, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (287, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (288, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (289, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (290, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (291, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (292, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (293, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (294, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (295, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (296, '李四', 22, '', 'E:\\upload\\3b9524574cb54397b3c42b99b2cf3174.jpeg', '22222222', 'fhyduoshuai', NULL, '17799991111', 1, 11, 1, NULL, NULL);
INSERT INTO `tb_user` VALUES (302, '方羽', 25, '', 'aaaaaaaaa', 'fhyduoshuai', 'fhy123456', NULL, '16688880000', 0, 9, 2, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
